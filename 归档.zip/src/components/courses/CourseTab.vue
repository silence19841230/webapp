<template>
  <div>
		<h1>
		tab页面
		</h1>

  </div>
</template>

<script>

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
