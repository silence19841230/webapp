<template>
      <div>
        <button @click="getCourse()">获取课程</button>
        <button @click="getQuestions()">去做题</button>

      </div>




</template>


<script>




  import axios from "axios";
  import Store from "../js/store";
  import Common from "../js/common";



  export default {
    name: 'Main',
    data: function () {
      return {

      }
    },
    methods: {
      getCourse: function () {
        axios({
          method: Common.method_post,
          url: Common.baseUrl + '/courses',
          contentType: Common.contentType,
          dataType: Common.dataType,
          headers: Common.jwt_header,
          data: {
            lang: Common.lang,
            agent: Common.agent,
            intfVer: Common.intfVer,
            payload: {
              params: {
                productId: Common.productId,
                courseType: Common.courseType
              }
            }
          },
        })
          .then(function (response) {
            if (response.data.ok) {
              console.log(response.data);
            }

          })
          .catch(function (response) {
            console.log(response);
          });

      },
      getQuestions:function () {
        this.$router.push("/question");
      },
      getCourse:function () {
        this.$router.push("/course");
      }
    }


  }

</script>

<style scoped>


</style>
