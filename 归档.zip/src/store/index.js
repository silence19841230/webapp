import Vue from 'vue'
import Vuex from 'vuex'
import QuestionsStore from "./modules/questionstroe"


Vue.use(Vuex)


const store = new Vuex.Store({
  modules: {
    questionstroe:QuestionsStore
  }
})


export default store
