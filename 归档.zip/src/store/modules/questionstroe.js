
const state = {
  list:  [
    {
      "A": "古代会计",
      "B": "近代会计",
      "C": "现代会计",
      "D": "当代会计",
      "da": ["A","B","C"],
      "id": "0b01ecd157c270010157c271d6e2000f",
      "txing": "duoxuan",
      "name": "会计是随着人类社会生产的发展和经济管理的需要而产生、发展并不",
      "selected": [],
      "tg": "会计是随着人类社会生产的发展和经济管理的需要而产生、发展并不断得到完善。其中，会计的发展可划分为（    ）阶段。",
      "txi": "题目解析: 会计是随着人类社会生产的发展和经济管理的需要而产生、发展并不断得到完善。其中，会计的发展可划分为古代会计、近代会计和现代会计三个阶段。",
      "isReaded": false,
      "isCollection": 0
    }
  ],

  status:{
  }
}

// getters
const getters = {
  list: (state) => {

    return state.list;
  },
  // da_result:(state)=>(index)=>{
  //
  //
  //   var src_obj = state.list[index].selected;
  //   var target_obj = state.list[index].da;
  //
  //   var src_obj_array = new Array();
  //   var target_obj_array = new Array();
  //   //如果是String转换成数组。
  //   if (!Array.isArray(src_obj)) {
  //     src_obj_array.push(src_obj);
  //   } else {
  //     src_obj_array = src_obj;
  //   }
  //
  //   if (!Array.isArray(target_obj)) {
  //     target_obj_array.push(target_obj);
  //   } else {
  //     target_obj_array = target_obj;
  //   }
  //
  //   return src_obj_array.sort().toString() === target_obj_array.sort().toString();
  // }
  // ,
  status:(state)=>{
    return state.status;
  }

}

// mutations
const mutations = {
  setList (state, list) {
    state.list = list;
  },

  setListQuestionSelected (state, current,selected) {
    state.list[current]["selected"] = selected;

    var src_obj = selected;
    var target_obj = state.list[current].da;

    var src_obj_array = new Array();
    var target_obj_array = new Array();
    //如果是String转换成数组。
    if (!Array.isArray(src_obj)) {
      src_obj_array.push(src_obj);
    } else {
      src_obj_array = src_obj;
    }

    if (!Array.isArray(target_obj)) {
      target_obj_array.push(target_obj);
    } else {
      target_obj_array = target_obj;
    }

    state.list[current]["da_result"] =  src_obj_array.sort().toString() === target_obj_array.sort().toString();

  },
  setCheckDaBoolean(state,checkDaBoolean){
    state.status["checkDaBoolean"] = checkDaBoolean;
  }
  // ,
  // incrementIndex(){
  //   state.index++;
  //   if(state.index>=state.list.length-1){
  //     state.index=state.list.length-1;
  //   }
  // },
  // reduceIndex(){
  //   state.index--;
  //   if(state.index<=0){
  //     state.index = 0;
  //   }
  // }
}

const actions = {

  setList ({ commit },list) {
    commit('setList',list)
  },
  setCheckDaBoolean({ commit },checkDaBoolean){
    commit('setCheckDaBoolean',checkDaBoolean);
  },
  setListQuestionSelected ({ commit }, current,selected) {
    commit('setListQuestionSelected',current,selected);
  },
  // ,
  // incrementIndex({ commit }){
  //   commit('incrementIndex');
  // },
  // reduceIndex({ commit }){
  //   commit('reduceIndex');
  // }

}

export default {
  state,
  getters,
  actions,
  mutations
}
